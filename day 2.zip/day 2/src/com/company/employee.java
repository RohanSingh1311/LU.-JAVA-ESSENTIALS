package com.company;

public class employee {

    String ename;
    int eage;
    String ecity;
    



    public void displayDetails(){

        System.out.println("The name is: "+ ename );
        System.out.println("The age is: "+ eage);
        System.out.println("The city is: "+ ecity);
    }

}
